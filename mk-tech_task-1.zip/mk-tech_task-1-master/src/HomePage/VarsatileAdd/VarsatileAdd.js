import React, { useState } from "react";
import Tab from "./Tab";
import "./VarsatileAdd.css";

const VarsatileAdd = () => {
  const data = [
    {
      id: 1,
      title: "POP-UNDER 1",
      text: "Hello, Here will be a text",
      image:
        "https://masterkey-assignment-01.netlify.app/static/media/advertisement.99456113d960ac0b467e.png",
    },
    {
      id: 2,
      title: "POP-UNDER 2",
      text: "Hello, Here will be a text",
      image:
        "https://masterkey-assignment-01.netlify.app/static/media/advertisement.99456113d960ac0b467e.png",
    },
    {
      id: 3,
      title: "POP-UNDER 3",
      text: "Hello, Here will be a text",
      image:
        "https://masterkey-assignment-01.netlify.app/static/media/advertisement.99456113d960ac0b467e.png",
    },
    {
      id: 4,
      title: "POP-UNDER 4",
      text: "Hello, Here will be a text",
      image:
        "https://masterkey-assignment-01.netlify.app/static/media/advertisement.99456113d960ac0b467e.png",
    },
    {
      id: 5,
      title: "POP-UNDER 5",
      text: "Hello, Here will be a text",
      image:
        "https://masterkey-assignment-01.netlify.app/static/media/advertisement.99456113d960ac0b467e.png",
    },
  ];
  const [tabs, setTabs] = useState(1);
  return (
    <div className="mainPadding addPage">
      <div className="dashedLine">
        <h2>VERSATILE AD FORMATS</h2>
      </div>

      <div className="addButtons">
        <button
          className={tabs === 1 ? "activeAddButton" : "addButton"}
          onClick={() => setTabs(1)}
        >
          POP-UNDER
        </button>
        <button
          className={tabs === 2 ? "activeAddButton" : "addButton"}
          onClick={() => setTabs(2)}
        >
          BANNER AD{" "}
        </button>
        <button
          className={tabs === 3 ? "activeAddButton" : "addButton"}
          onClick={() => setTabs(3)}
        >
          NATIVE
        </button>
        <button
          className={tabs === 4 ? "activeAddButton" : "addButton"}
          onClick={() => setTabs(4)}
        >
          SKIM
        </button>
      </div>
      <div>
        <Tab data={data[tabs]} />
      </div>
    </div>
  );
};

export default VarsatileAdd;
