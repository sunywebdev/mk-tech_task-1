import React from 'react';

const NavBar = () => {
    return (
        <div>
            This is navbar
        </div>
    );
};

export default NavBar;